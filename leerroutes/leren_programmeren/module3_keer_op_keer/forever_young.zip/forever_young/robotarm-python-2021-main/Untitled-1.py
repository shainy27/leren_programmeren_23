zin = input("Voer een woord in")


for x in zin:
    pass

print("Halllooo")